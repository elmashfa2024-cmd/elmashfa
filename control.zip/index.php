<?php
session_start();
require_once 'config/database.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['role'];
$userName = $_SESSION['full_name'];

// جلب الإحصائيات حسب الصلاحية
if ($userRole === 'admin') {
    $totalPatients = $pdo->query("SELECT COUNT(*) FROM patients WHERE status='active'")->fetchColumn();
    $totalDebt = $pdo->query("SELECT COALESCE(SUM(total_debt), 0) FROM patients WHERE status='active'")->fetchColumn();
    $totalPaid = $pdo->query("SELECT COUNT(*) FROM patients WHERE status='active' AND total_debt=0")->fetchColumn();
    $totalLate = $pdo->query("SELECT COUNT(*) FROM patients WHERE status='active' AND total_debt>0 AND risk_level IN ('high','medium')")->fetchColumn();
    $totalDanger = $pdo->query("SELECT COUNT(*) FROM patients WHERE status='active' AND risk_level='high'")->fetchColumn();
} elseif ($userRole === 'referrer') {
    // المحول يشوف نزلاءه فقط
    $totalPatients = $pdo->prepare("SELECT COUNT(*) FROM patients WHERE status='active' AND referrer_id=?");
    $totalPatients->execute([$userId]);
    $totalPatients = $totalPatients->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - مركز المشفى</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="layout">

<!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-logo">
        <div class="logo-icon">🏥</div>
        <div>
            <div class="logo-text">مركز المشفي</div>
            <div class="logo-sub">الطب النفسي وعلاج الإدمان</div>
        </div>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section">
            <div class="nav-label">الرئيسية</div>
            <div class="nav-item active" onclick="navigate('dashboard', this)">
                <span class="icon">📊</span> الداشبورد
            </div>
        </div>

        <?php if ($userRole === 'admin' || $userRole === 'referrer'): ?>
        <div class="nav-section">
            <div class="nav-label">النزلاء</div>
            <div class="nav-item" onclick="navigate('patients', this)">
                <span class="icon">🏥</span> كل النزلاء
            </div>
            <?php if ($userRole === 'admin'): ?>
            <div class="nav-item" onclick="navigate('late', this)">
                <span class="icon">⚠️</span> المتأخرون
                <span class="nav-badge" id="late-badge">0</span>
            </div>
            <div class="nav-item" onclick="navigate('archive', this)">
                <span class="icon">📦</span> الأرشيف
            </div>
			<div class="nav-item" onclick="navigate('consumables', this)">
    <span class="icon">🚬</span> السجائر والمصاريف
</div>
			
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if ($userRole === 'admin'): ?>
        <div class="nav-section">
            <div class="nav-label">المالية</div>
            <div class="nav-item" onclick="navigate('payments', this)">
                <span class="icon">💳</span> سجل الدفعات
            </div>
            <div class="nav-item" onclick="navigate('referrers', this)">
                <span class="icon">👥</span> المحولون
            </div>
        </div>
        <?php endif; ?>

        <?php if ($userRole === 'specialist'): ?>
        <div class="nav-section">
            <div class="nav-label">الزيارات</div>
            <div class="nav-item" onclick="navigate('visits', this)">
                <span class="icon">📋</span> جدول الزيارات
            </div>
        </div>
        <?php endif; ?>
   <?php if ($userRole === 'admin'): ?>
        <div class="nav-section">
            <div class="nav-label">التقارير</div>
            <div class="nav-item" onclick="navigate('stats', this)">
                <span class="icon">📈</span> الإحصائيات
            </div>
        </div>
        <?php endif; ?>
		<?php if ($userRole === 'specialist' || $userRole === 'admin'): ?>
<div class="nav-section">
    <div class="nav-label">الزيارات</div>
    <div class="nav-item" onclick="navigate('today', this)">
        <span class="icon">📅</span> زيارات اليوم
    </div>
    <div class="nav-item" onclick="navigate('tomorrow', this)">
        <span class="icon">🔮</span> <span id="tomorrow-label">زيارات بكرة</span>
    </div>
    <div class="nav-item" onclick="navigate('visits', this)">
        <span class="icon">📋</span> كل الزيارات
    </div>
</div>
<?php endif; ?>

    </nav>

    <div class="sidebar-footer">
        <div class="user-info">
            <div class="user-avatar"><?php echo mb_substr($userName, 0, 1); ?></div>
            <div>
                <div class="user-name"><?php echo htmlspecialchars($userName); ?></div>
                <div class="user-role"><?php echo $userRole === 'admin' ? 'مدير' : ($userRole === 'referrer' ? 'محول' : 'أخصائي'); ?></div>
            </div>
        </div>
        <div class="current-date" id="current-date"></div>
        <a href="logout.php" class="btn btn-ghost" style="width:100%;margin-top:8px;justify-content:center;">🚪 تسجيل الخروج</a>
    </div>
</aside>

<!-- MOBILE OVERLAY -->
<div class="overlay-bg" id="overlay-bg" onclick="closeSidebar()"></div>

<!-- MAIN -->
<main class="main">
    <header class="header">
        <button class="menu-toggle" onclick="toggleSidebar()">☰</button>
        <div>
            <div class="header-title" id="page-title">الداشبورد</div>
            <div class="header-sub" id="page-sub">نظرة عامة على المركز</div>
        </div>
        <div class="header-actions">
            <?php if ($userRole === 'admin'): ?>
            <button class="btn btn-primary" onclick="openAddPatientModal()">➕ نزيل جديد</button>
            <?php endif; ?>
        </div>
    </header>

    <div class="content">
	<!-- TODAY VISITS -->
<div class="page" id="page-today">
    <div class="table-wrap">
        <div class="table-header">
            <div style="font-size:14px; font-weight:700;">📅 زيارات اليوم</div>
        </div>
        <div id="today-list" style="padding:20px;"></div>
    </div>
</div>

<!-- TOMORROW VISITS -->
<div class="page" id="page-tomorrow">
    <div class="table-wrap">
        <div class="table-header">
            <div style="font-size:14px; font-weight:700;" id="tomorrow-title">📅 زيارات بكرة</div>
        </div>
        <div id="tomorrow-list" style="padding:20px;"></div>
    </div>
</div>
	<!-- ========== REFERRERS PAGE ========== -->
<div class="page" id="page-referrers">
    <div class="table-wrap">
        <div class="table-header">
            <div style="font-size:14px; font-weight:700;">👥 تقرير المحولين</div>
			 <button class="btn btn-primary btn-sm" onclick="openReferrerModal()">➕ إضافة محول</button>
        </div>
        <div class="table-scroll">
            <table>
                <thead>
                    <tr>
					
                        <th>#</th>
                        <th>المحوِّل</th>
                        <th>عدد النزلاء</th>
                        <th>إجمالي المدفوع</th>
                        <th>إجمالي المديونية</th>
                        <th>نسبة التحصيل</th>
                    </tr>
                </thead>
                <tbody id="referrers-body"></tbody>
            </table>
        </div>
    </div>
</div>

<!-- ========== STATS PAGE ========== -->
<div class="page" id="page-stats">
    <div class="stats-grid" style="margin-bottom:24px;">
        <div class="stat-card green">
            <span class="stat-icon">💰</span>
            <div class="stat-label">إجمالي المحصّل</div>
            <div class="stat-value" id="total-collected">0</div>
            <div class="stat-sub">جنيه</div>
        </div>
        <div class="stat-card red">
            <span class="stat-icon">📉</span>
            <div class="stat-label">إجمالي المديونية</div>
            <div class="stat-value" id="total-debt-stats">0</div>
            <div class="stat-sub">جنيه</div>
        </div>
    </div>
</div>
        <!-- ========== DASHBOARD ========== -->
        <div class="page active" id="page-dashboard">
            <?php if ($userRole === 'admin'): ?>
            <div class="stats-grid">
                <div class="stat-card blue">
                    <span class="stat-icon">🏥</span>
                    <div class="stat-label">إجمالي النزلاء</div>
                    <div class="stat-value" id="stat-total">0</div>
                    <div class="stat-sub">نزيل مقيم حالياً</div>
                </div>
                <div class="stat-card red">
                    <span class="stat-icon">💸</span>
                    <div class="stat-label">إجمالي المديونية</div>
                    <div class="stat-value" id="stat-debt">0</div>
                    <div class="stat-sub">جنيه مصري</div>
                </div>
                <div class="stat-card green">
                    <span class="stat-icon">✅</span>
                    <div class="stat-label">مسددون بالكامل</div>
                    <div class="stat-value" id="stat-paid">0</div>
                    <div class="stat-sub">نزيل</div>
                </div>
                <div class="stat-card yellow">
                    <span class="stat-icon">⚠️</span>
                    <div class="stat-label">متأخرون</div>
                    <div class="stat-value" id="stat-late">0</div>
                    <div class="stat-sub">نزيل</div>
                </div>
                <div class="stat-card orange">
                    <span class="stat-icon">🔴</span>
                    <div class="stat-label">خطر عالي</div>
                    <div class="stat-value" id="stat-danger">0</div>
                    <div class="stat-sub">نزيل</div>
                </div>
				<div class="stat-card purple">
    <span class="stat-icon">📦</span>
    <div class="stat-label">الأرشيف</div>
    <div class="stat-value" id="stat-archive">0</div>
    <div class="stat-sub">نزيل تم أرشفته</div>
</div>
            </div>
            <?php elseif ($userRole === 'referrer'): ?>
            <div class="stats-grid">
                <div class="stat-card blue">
                    <span class="stat-icon">🏥</span>
                    <div class="stat-label">النزلاء المحولين بواسطتك</div>
                    <div class="stat-value" id="stat-total">0</div>
                </div>
            </div>
            <?php elseif ($userRole === 'specialist'): ?>
            <div class="stats-grid">
                <div class="stat-card blue">
                    <span class="stat-icon">📋</span>
                    <div class="stat-label">زيارات اليوم</div>
                    <div class="stat-value" id="stat-visits">0</div>
                </div>
            </div>
            <?php endif; ?>
            
            <div id="dashboard-content"></div>
        </div>

        <!-- ========== PATIENTS PAGE ========== -->
        <div class="page" id="page-patients">
            <div class="table-wrap">
                <div class="table-header">
                    <div class="search-box">
                        <span>🔍</span>
                        <input type="text" placeholder="ابحث بالاسم..." oninput="searchPatients(this.value)" id="patient-search">
                    </div>
                    <?php if ($userRole === 'admin'): ?>
                    <select class="filter-select" onchange="filterPatients(this.value)" id="status-filter">
                        <option value="">كل الحالات</option>
                        <option value="high">🔴 خطر عالي</option>
                        <option value="medium">🟡 تنبيه</option>
                        <option value="low">🟢 طبيعي</option>
                        <option value="paid">✅ مسدد</option>
                    </select>
                    <?php endif; ?>
                </div>
                <div class="table-scroll">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>الاسم</th>
                                <th>تاريخ الدخول</th>
                                <th>المبلغ/شهر</th>
                                <th>المدفوع</th>
                                <th>المديونية</th>
                                <?php if ($userRole === 'admin'): ?>
								<th>المتأخر</th>
                                <th>المحوِّل</th>
                                <th>الحالة</th>
                                <th>إجراءات</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody id="patients-body"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ========== LATE PAGE ========== -->
        <div class="page" id="page-late">
            <div class="table-wrap">
                <div class="table-header">
                    <div style="font-size:14px; font-weight:700; color:var(--red);">⚠️ النزلاء المتأخرون في السداد</div>
                </div>
                <div class="table-scroll">
                    <table>
                        <thead>
    <tr>
        <th>#</th>
        <th>الاسم</th>
        <th>تاريخ الدخول</th>
        <th>المتأخر</th>
       <th>المحوِّل</th>
    </tr>
</thead>
                        <tbody id="late-body"></tbody>
                    </table>
                </div>
            </div>
        </div>
<!-- ========== CONSUMABLES PAGE ========== -->
<div class="page" id="page-consumables">

    <div class="table-wrap">
		
        <div class="table-header">
		
		<button class="btn btn-primary btn-sm" onclick="updateMonthlyCigaretteDebt()">🔄 تحديث المديونية الشهرية</button>
            <div style="font-size:14px; font-weight:700;">🚬 السجائر والمصاريف الخارجية</div>
        </div>
        <div class="table-scroll">
            <table>
                <thead>
    <tr>
        <th>النزيل</th>
        <th>🚬 رصيد سجائر (الأهل)</th>
        <th>📊 عليه سجائر (المركز)</th>
        <th>📉 مديونية مصاريف</th>
        <th>💰 رصيد مصاريف(الأهل)</th>
        <th>📉 صافي المديونية</th>
        <th>إجراءات</th>
    </tr>
</thead>
                <tbody id="consumables-body"></tbody>
            </table>
        </div>
    </div>
</div>
        <!-- ========== ARCHIVE PAGE ========== -->
        <div class="page" id="page-archive">
            <div class="table-wrap">
                <div class="table-header">
                    <div style="font-size:14px; font-weight:700;">📦 النزلاء الذين غادروا المركز</div>
                </div>
                <div class="table-scroll">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>الاسم</th>
                                <th>تاريخ الدخول</th>
                                <th>تاريخ الخروج</th>
                                <th>المدفوع</th>
                                <th>المديونية</th>
                            </tr>
                        </thead>
                        <tbody id="archive-body"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ========== PAYMENTS PAGE ========== -->
        <div class="page" id="page-payments">
            <div class="table-wrap">
                <div class="table-header">
                    <div style="font-size:14px; font-weight:700;">💳 سجل الدفعات</div>
                    <button class="btn btn-success" onclick="openPaymentModal()">➕ تسجيل دفعة</button>
                </div>
                <div id="payments-list" style="padding:20px;"></div>
            </div>
        </div>

        <!-- ========== VISITS PAGE (للأخصائي) ========== -->
      <div class="page" id="page-visits">
    <div class="table-wrap">
        <div class="table-header">
            <div style="font-size:14px; font-weight:700;">📋 جدول الزيارات</div>
            <div style="display:flex;gap:8px;">
                <div class="search-box" style="min-width:200px;">
                    <span>🔍</span>
                    <input type="text" placeholder="ابحث عن نزيل..." oninput="searchVisits(this.value)" id="visit-search">
                </div>
                <button class="btn btn-primary" onclick="openVisitModal()">➕ تسجيل زيارة</button>
				<button class="btn btn-danger" onclick="deleteAllVisits()">🗑️ حذف الكل</button>
            </div>
        </div>
        <div id="visits-list" style="padding:20px;"></div>
    </div>
</div>
    </div>
</main>
</div>

<!-- ========== MODALS ========== -->

<!-- Add/Edit Patient Modal -->
<div class="modal-overlay" id="patient-modal">
    <div class="modal">
        <div class="modal-head">
            <h3 id="modal-title">➕ إضافة نزيل جديد</h3>
            <button class="modal-close" onclick="closeModal('patient-modal')">×</button>
        </div>
        <div class="modal-body">
            <div class="form-grid">
                <div class="form-group span2">
                    <label>الاسم الكامل *</label>
                    <input type="text" id="f-name" placeholder="اكتب الاسم هنا">
                </div>
                <div class="form-group">
                    <label>تاريخ الدخول *</label>
                    <input type="date" id="f-date">
                </div>
               <div class="form-group">
    <label>مبلغ الإقامة/شهر</label>
    <input type="text" id="f-amount" placeholder="0" onchange="checkAmountType()">
    <small style="color:var(--text3);font-size:11px;">اكتب رقماً أو "دعم" أو "لم يحدد"</small>
</div>
                <div class="form-group">
                    <label>إجمالي المدفوع (ج)</label>
                    <input type="number" id="f-paid" placeholder="0">
                </div>
				<div class="form-group">
    <label>🚬 عدد السجاير اليومية</label>
    <input type="number" id="f-cigarettes-daily" placeholder="0" value="0" oninput="calculateMonthlyCigarettes()">
</div>
<div class="form-group">
    <label>📦 عدد العلب الشهرية (تلقائي)</label>
    <input type="text" id="f-cigarettes-monthly" placeholder="0" readonly style="background:var(--bg3);color:var(--accent);font-weight:700;">
    <small style="color:var(--text3);font-size:11px;">العلبة = 20 سيجارة | 30 يوم</small>
</div>
                <div class="form-group">
                    <label>المحوِّل</label>
                    <input type="text" id="f-ref" placeholder="اسم الجهة أو الشخص">
                </div>
                <div class="form-group">
                    <label>تليفون النزيل</label>
                    <input type="tel" id="f-phone" placeholder="01xxxxxxxxx">
                </div>
                <div class="form-group">
                    <label>اسم ولي الأمر</label>
                    <input type="text" id="f-guardian" placeholder="الاسم">
                </div>
                <div class="form-group">
                    <label>تليفون ولي الأمر</label>
                    <input type="tel" id="f-guardian-phone" placeholder="01xxxxxxxxx">
                </div>
                <div class="form-group">
                    <label>التشخيص</label>
                    <select id="f-diagnosis">
                        <option value="">— اختر —</option>
                        <option>إدمان</option>
                        <option>نفسي</option>
                        <option>مزدوج</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>الطبيب المعالج</label>
                    <input type="text" id="f-doctor" placeholder="اسم الدكتور">
                </div>
                <div class="form-group span2">
                    <label>ملاحظات</label>
                    <textarea id="f-notes" placeholder="أي ملاحظات إضافية..."></textarea>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" onclick="closeModal('patient-modal')">إلغاء</button>
            <button class="btn btn-primary" onclick="savePatient()">💾 حفظ</button>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div class="modal-overlay" id="payment-modal">
    <div class="modal" style="max-width:440px;">
        <div class="modal-head">
            <h3>💳 تسجيل دفعة جديدة</h3>
            <button class="modal-close" onclick="closeModal('payment-modal')">×</button>
        </div>
        <div class="modal-body">
            <div class="form-grid full">
                <div class="form-group">
                    <label>اسم النزيل *</label>
                    <select id="p-patient"></select>
                </div>
                <div class="form-group">
                    <label>المبلغ (ج) *</label>
                    <input type="number" id="p-amount" placeholder="0">
                </div>
                <div class="form-group">
                    <label>تاريخ الدفع</label>
                    <input type="date" id="p-date">
                </div>
                <div class="form-group">
                    <label>طريقة الدفع</label>
                    <select id="p-method">
                        <option>كاش</option>
                        <option>تحويل بنكي</option>
                        <option>انستاباي</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>استلم من</label>
                    <input type="text" id="p-from" placeholder="اسم المدفوع">
                </div>
                <div class="form-group">
                    <label>ملاحظة</label>
                    <textarea id="p-notes" style="min-height:60px;"></textarea>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" onclick="closeModal('payment-modal')">إلغاء</button>
            <button class="btn btn-success" onclick="savePayment()">✅ تسجيل الدفعة</button>
        </div>
    </div>
</div>

<!-- Visit Modal -->
<div class="modal-overlay" id="visit-modal">
    <div class="modal" style="max-width:440px;">
        <div class="modal-head">
            <h3>📋 تسجيل زيارة</h3>
            <button class="modal-close" onclick="closeModal('visit-modal')">×</button>
        </div>
        <div class="modal-body">
            <div class="form-grid full">
                <div class="form-group">
                    <label>اسم النزيل *</label>
                    <select id="v-patient"></select>
                </div>
                <div class="form-group">
                    <label>تاريخ الزيارة *</label>
                    <input type="date" id="v-date">
                </div>
                <div class="form-group">
                    <label>الوقت</label>
                    <input type="time" id="v-time">
                </div>
                <div class="form-group">
                    <label>ملاحظات</label>
                    <textarea id="v-notes" style="min-height:80px;"></textarea>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" onclick="closeModal('visit-modal')">إلغاء</button>
            <button class="btn btn-primary" onclick="saveVisit()">✅ حفظ الزيارة</button>
        </div>
    </div>
</div>
        <?php if ($userRole === 'admin'): ?>
        <!-- Add Referrer Modal -->
<div class="modal-overlay" id="referrer-modal">
    <div class="modal" style="max-width:440px;">
        <div class="modal-head">
            <h3>👥 إضافة محول جديد</h3>
            <button class="modal-close" onclick="closeModal('referrer-modal')">×</button>
        </div>
        <div class="modal-body">
            <div class="form-grid full">
                <div class="form-group"><label>اسم المحول *</label><input type="text" id="r-name"></div>
                <div class="form-group"><label>رقم الهاتف</label><input type="tel" id="r-phone"></div>
                <div class="form-group"><label>اسم المستخدم</label><input type="text" id="r-username"></div>
                <div class="form-group"><label>كلمة المرور</label><input type="password" id="r-password"></div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" onclick="closeModal('referrer-modal')">إلغاء</button>
            <button class="btn btn-primary" onclick="saveReferrer()">💾 حفظ</button>
        </div>
    </div>
</div>
        <?php endif; ?>
		<!-- Consumable Modal -->
<div class="modal-overlay" id="consumable-modal">
    <div class="modal" style="max-width:500px;">
        <div class="modal-head">
            <h3 id="consumable-title">🚬 إدارة السجائر والمصاريف</h3>
            <button class="modal-close" onclick="closeModal('consumable-modal')">×</button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="c-patient-id">
            <div class="stats-grid" style="margin-bottom:16px;">
                <div class="stat-card blue" style="padding:12px;">
                    <div class="stat-label">🚬 رصيد السجائر (بالسيجاره) </div>
                    <div class="stat-value" id="c-cig-balance" style="font-size:20px;">0 <</div>
			
                </div>
                <div class="stat-card green" style="padding:12px;">
                    <div class="stat-label">💰 رصيد خارجي</div>
                    <div class="stat-value" id="c-ext-balance" style="font-size:20px;">0 ج</div>
                </div>
                <div class="stat-card red" style="padding:12px;">
                    <div class="stat-label">📉 مديونية خارجية</div>
                    <div class="stat-value" id="c-ext-debt" style="font-size:20px;">0 ج</div>
                </div>
              <div class="stat-card yellow" style="padding:12px;">
    <div class="stat-label">📊 عليه سجائر (المركز)</div>
    <div class="stat-value" id="c-center-cig" style="font-size:20px;">0</div>
</div>
            </div>
            
            <div class="tabs" style="margin-bottom:16px;">
                <div class="tab active" onclick="switchConsumableTab('cigarettes')">🚬 سجائر</div>
                <div class="tab" onclick="switchConsumableTab('external')">💰 مصاريف</div>
            </div>
            
            <!-- سجائر -->
            <div id="tab-cigarettes">
                <div class="form-grid full">
                    <div class="form-group">
                        <label>النوع</label>
                        <select id="c-type">
                            <option value="add">➕ إضافة سجائر (من الأهل)</option>
                            <option value="remove">➖ صرف سجائر للنزيل</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>الكمية (بالعدد)</label>
                        <input type="number" id="c-qty" placeholder="0" min="1">
                    </div>
                    <div class="form-group">
                        <label>ملاحظة</label>
                        <input type="text" id="c-notes" placeholder="تفاصيل...">
                    </div>
                </div>
                <button class="btn btn-primary w-100 mt-3" onclick="saveCigaretteTransaction()">💾 تسجيل</button>
            </div>
            
            <!-- مصاريف -->
            <div id="tab-external" style="display:none;">
                <div class="form-grid full">
                    <div class="form-group">
                        <label>النوع</label>
                        <select id="e-type">
                            <option value="deposit">💰 إيداع من الأهل</option>
                            <option value="expense">💸 صرف مبلغ</option>
                            <option value="charge">📋 تسجيل مديونية (على حساب المركز)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>المبلغ (ج)</label>
                        <input type="number" id="e-amount" placeholder="0" min="1">
                    </div>
                    <div class="form-group">
                        <label>ملاحظة</label>
                        <input type="text" id="e-notes" placeholder="تفاصيل الصرف...">
                    </div>
                </div>
                <button class="btn btn-primary w-100 mt-3" onclick="saveExternalTransaction()">💾 تسجيل</button>
            </div>
        </div>
    </div>
</div>
<!-- Transactions Modal -->
<div class="modal-overlay" id="transactions-modal">
    <div class="modal" style="max-width:500px;">
        <div class="modal-head">
            <h3>📋 سجل المعاملات</h3>
            <button class="modal-close" onclick="closeModal('transactions-modal')">×</button>
        </div>
        <div class="modal-body" id="transactions-list"></div>
    </div>
</div>
<!-- TOAST -->
<div class="toast-container" id="toasts"></div>

<script src="assets/script.js"></script>
<!-- Patient Detail Modal -->
<div class="modal-overlay" id="detail-modal">
    <div class="modal" style="max-width:640px;">
        <div class="modal-head">
            <h3 id="detail-name">👤 تفاصيل النزيل</h3>
            <button class="modal-close" onclick="closeModal('detail-modal')">×</button>
        </div>
        <div class="modal-body" id="detail-body"></div>
        <div class="modal-footer">
            <button class="btn btn-ghost" onclick="closeModal('detail-modal')">إغلاق</button>
        </div>
    </div>
</div>

<!-- Archive Warning Modal -->
<div class="modal-overlay" id="archive-warning-modal">
    <div class="modal" style="max-width:440px;">
        <div class="modal-head" style="background: #ef4444; color: white;">
            <h3>⚠️ تنبيه مديونية</h3>
            <button class="modal-close" onclick="closeModal('archive-warning-modal')" style="color:white;">×</button>
        </div>
        <div class="modal-body text-center">
            <div style="font-size:48px;margin-bottom:12px;">⚠️</div>
            <h4 id="warning-patient-name"></h4>
            <p style="color: var(--red); font-size: 18px; font-weight: 700;" id="warning-amount"></p>
            <p style="color: var(--text2);">هذا النزيل عليه مديونية مستحقة</p>
            <p style="font-size: 13px; color: var(--yellow);">هل أنت متأكد من متابعة الأرشفة؟</p>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" onclick="closeModal('archive-warning-modal')">إلغاء</button>
            <button class="btn btn-danger" id="confirm-archive-btn">⚠️ نعم، أرشفة مع المديونية</button>
        </div>
    </div>
</div>
<div class="modal-overlay" id="transactions-modal">
    <div class="modal" style="max-width:500px;">
        <div class="modal-head">
            <h3>📋 سجل المعاملات</h3>
            <button class="modal-close" onclick="closeModal('transactions-modal')">×</button>
        </div>
        <div class="modal-body" id="transactions-list"></div>
    </div>
</div>
    <script>
    const isAdmin = <?php echo ($userRole === 'admin') ? 'true' : 'false'; ?>;
</script>
<script>
    const currentUserName = "<?php echo $_SESSION['full_name'] ?? $userName ?? ''; ?>";
    const currentUserRole = "<?php echo $userRole; ?>";
</script>
</body>
</html>