// ══════════════════════════════════════
// STATE
// ══════════════════════════════════════
let patients = [];
let payments = [];
let editingId = null;

// ══════════════════════════════════════
// NAVIGATION
// ══════════════════════════════════════
const pageMeta = {
    dashboard: { title: 'الداشبورد', sub: 'نظرة عامة على المركز' },
    patients: { title: 'كل النزلاء', sub: 'قائمة جميع النزلاء المقيمين' },
    late: { title: 'المتأخرون', sub: 'النزلاء المتأخرون في السداد' },
    archive: { title: 'الأرشيف', sub: 'النزلاء الذين غادروا' },
    payments: { title: 'سجل الدفعات', sub: 'تسجيل ومتابعة الدفعات' },
    referrers: { title: 'المحولون', sub: 'تقرير أداء المحولين' },
    stats: { title: 'الإحصائيات', sub: 'إحصائيات وتحليلات شاملة' },
    visits: { title: 'الزيارات', sub: 'جدول زيارات النزلاء' },
};

function navigate(page, el) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    const pageEl = document.getElementById('page-' + page);
    if (pageEl) pageEl.classList.add('active');
    if (el) el.classList.add('active');
    
    const meta = pageMeta[page];
    if (meta) {
        document.getElementById('page-title').textContent = meta.title;
        document.getElementById('page-sub').textContent = meta.sub;
    }
    
    closeSidebar();
	if (page === 'today') renderToday();
if (page === 'tomorrow') renderTomorrow();
    if (page === 'stats') renderStats();
    if (page === 'patients') loadPatients();
    if (page === 'late') renderLate();
    if (page === 'archive') renderArchive();
	if (page === 'consumables') loadConsumables();
    if (page === 'referrers') renderReferrers();
    if (page === 'payments') loadPayments();
    if (page === 'visits') loadVisits();
}

// ══════════════════════════════════════
// MODALS
// ══════════════════════════════════════
function openModal(id) {
    document.getElementById(id).classList.add('open');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('open');
}

document.addEventListener('DOMContentLoaded', function() {
    // تهيئة التاريخ
    updateDate();
    
    // تحميل البيانات
    loadDashboard();
    loadPatients();
    
    // ضمان زرار إضافة نزيل
    const addBtn = document.querySelector('.btn-primary[onclick*="openAddPatientModal"]');
    if (addBtn) {
        addBtn.onclick = openAddPatientModal;
    }
    
    // إغلاق المودال عند الضغط على الـ overlay
    document.querySelectorAll('.modal-overlay').forEach(o => {
        o.addEventListener('click', e => {
            if (e.target === o) o.classList.remove('open');
        });
    });
    
    // إغلاق المودال عند الضغط على ESC
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay.open').forEach(o => o.classList.remove('open'));
        }
    });
});

// ══════════════════════════════════════
// TOAST
// ══════════════════════════════════════
function toast(msg, type = 'success') {
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.innerHTML = msg;
    document.getElementById('toasts').appendChild(t);
    setTimeout(() => t.remove(), 3500);
}

// ══════════════════════════════════════
// SIDEBAR
// ══════════════════════════════════════
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('overlay-bg').classList.toggle('open');
}

function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('overlay-bg').classList.remove('open');
}

// ══════════════════════════════════════
// HELPERS
// ══════════════════════════════════════
function fmtNum(n) { return Number(n || 0).toLocaleString('ar-EG'); }

function updateDate() {
    const now = new Date();
    const opts = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const el = document.getElementById('current-date');
    if (el) el.textContent = now.toLocaleDateString('ar-EG', opts);
}

// ══════════════════════════════════════
// LOAD DATA
// ══════════════════════════════════════
function loadDashboard() {
    var url = 'api/get_dashboard.php';
    if (typeof currentUserRole !== 'undefined' && currentUserRole === 'referrer' && typeof currentUserName !== 'undefined' && currentUserName) {
        url += '?referrer=' + encodeURIComponent(currentUserName);
    }
    fetch(url)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data.success && data.stats) {
                var s = data.stats;
                var setText = function(id, val) { var el = document.getElementById(id); if (el) el.textContent = val; };
                setText('stat-total', s.total_patients || 0);
                setText('stat-debt', fmtNum(s.total_debt || 0));
                setText('stat-paid', s.paid_count || 0);
                setText('stat-late', s.late_count || 0);
                setText('stat-danger', s.danger_count || 0);
                setText('stat-archive', s.archived_count || 0);
                setText('stat-visits', s.today_visits || 0);
            }
        });
}
function loadPatients() {
    var url = 'api/get_patients.php';
    if (currentUserRole === 'referrer' && currentUserName) {
        url = url + '?referrer=' + encodeURIComponent(currentUserName);
    }
    fetch(url)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data.success) { 
                patients = data.data; 
                renderPatients(); 
            }
        });
}
function loadPayments() {
    fetch('api/get_payments.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) { payments = data.data; renderPayments(); }
        })
        .catch(err => console.log('Payments error:', err));
}

function loadVisits() {
    fetch('api/get_visits.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) { renderVisits(data.data); }
        })
        .catch(err => console.log('Visits error:', err));
}

// ══════════════════════════════════════
// RENDER
// ══════════════════════════════════════
function renderDashboard() {
    loadDashboard();
    loadPayments();
}

function renderPatients() {
    const tbody = document.getElementById('patients-body');
    if (!tbody) return;
    if (!patients.length) {
        tbody.innerHTML = '<tr><td colspan="10"><div class="empty"><span class="icon">🏥</span><p>لا يوجد نزلاء</p></div></td></tr>';
        return;
    }
    tbody.innerHTML = patients.map((p, i) => `
        <tr>
            <td>${i + 1}</td>
            <td class="td-name" style="cursor:pointer;" onclick="showPatientDetail(${p.id})">${p.name}</td>
            <td class="td-date">${p.entry_date}</td>
            <td class="td-amount">${p.monthly_amount > 0 ? fmtNum(p.monthly_amount) + ' ج' : p.monthly_type === 'دعم' ? 'دعم' : p.monthly_type === 'لم يحدد' ? 'لم يحدد' : '0'}</td>
            <td class="td-paid">${fmtNum(p.total_paid)} ج</td>
            <td class="td-debt">${p.total_debt > 0 ? fmtNum(p.total_debt) + ' ج' : '<span style="color:var(--green)">✅ صفر</span>'}</td>
            <td style="color:var(--red);font-weight:700;">${p.overdue_months > 0 || p.overdue_days > 0 ? p.overdue_months + ' شهر ' + p.overdue_days + ' يوم' : '-'}</td>
            <td>${p.referrer_name || '-'}</td>
            <td><span class="badge badge-${p.total_debt > 0 ? (p.risk_level === 'high' ? 'red' : p.risk_level === 'medium' ? 'yellow' : 'orange') : 'green'}">${p.total_debt > 0 ? (p.risk_level === 'high' ? '🔴 خطر' : p.risk_level === 'medium' ? '🟡 متأخر' : '🟠 مراقبة') : '🟢 مسدد'}</span></td>
            <td onclick="event.stopPropagation()">
               ${typeof isAdmin !== 'undefined' && isAdmin ? `
    <button class="btn btn-ghost btn-sm" onclick="editPatient(${p.id})">✏️</button>
    <button class="btn btn-success btn-sm" onclick="openPaymentForPatient(${p.id})">💳</button>
    <button class="btn btn-danger btn-sm" onclick="archivePatient(${p.id})">📦</button>
` : ''}
            </td>
        </tr>
    `).join('');
}
function openReferrerModal() {
    document.getElementById('r-name').value = '';
    document.getElementById('r-phone').value = '';
    document.getElementById('r-username').value = '';
    document.getElementById('r-password').value = '';
    openModal('referrer-modal');
}

function saveReferrer() {
    const name = document.getElementById('r-name').value.trim();
    if (!name) { toast('⚠️ الاسم مطلوب', 'error'); return; }
    
    fetch('api/save_referrer.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            name: name,
            phone: document.getElementById('r-phone').value,
            username: document.getElementById('r-username').value,
            password: document.getElementById('r-password').value
        })
    })
    .then(res => res.json())
    .then(result => {
        if (result.success) { toast('✅ تم'); closeModal('referrer-modal'); }
        else toast('❌ ' + result.message, 'error');
    });
}
function renderPayments() {
    const container = document.getElementById('payments-list');
    if (!container) return;
    if (!payments.length) {
        container.innerHTML = '<div class="empty"><span class="icon">💳</span><p>لا يوجد دفعات</p></div>';
        return;
    }
    container.innerHTML = payments.map(p => `
        <div class="payment-item">
            <div class="payment-avatar">💳</div>
            <div class="payment-info">
               <div class="payment-name" style="cursor:pointer;" onclick="showPaymentDetail(${p.id})">${p.patient_name || '-'}</div> <div class="payment-date">${p.payment_date} · ${p.payment_method || 'كاش'}</div>
                ${p.notes ? `<div style="font-size:11px;color:var(--text3);">${p.notes}</div>` : ''}
            </div>
            <div class="payment-amount">+${fmtNum(p.amount)} ج</div>
        </div>
    `).join('');
}
function showPaymentDetail(id) {
    const p = payments.find(x => x.id == id);
    if (!p) return;
    alert(`💳 تفاصيل الدفعة\n\n👤 النزيل: ${p.patient_name || '-'}\n💰 المبلغ: ${fmtNum(p.amount)} ج\n📅 التاريخ: ${p.payment_date}\n💵 الطريقة: ${p.payment_method || 'كاش'}\n👤 استلم من: ${p.received_from || '-'}\n📝 ملاحظات: ${p.notes || 'لا يوجد'}`);
}
function renderStats() {
    fetch('api/get_stats.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                document.getElementById('total-collected').textContent = fmtNum(data.total_collected);
                document.getElementById('total-debt-stats').textContent = fmtNum(data.total_debt);
            }
        });
}
function renderVisits(data) {
    const container = document.getElementById('visits-list');
    if (!container) return;
    if (!data || !data.length) {
        container.innerHTML = '<div class="empty"><span class="icon">📋</span><p>لا يوجد زيارات</p></div>';
        return;
    }
    container.innerHTML = data.map(v => `
        <div class="visit-card">
            <div class="visit-card-header">
                <div class="visit-date-badge">
                    <span class="visit-day">${v.visit_date ? v.visit_date.split('-')[2] : '-'}</span>
                    <span class="visit-month">${v.visit_date ? getMonthName(v.visit_date.split('-')[1]) : '-'}</span>
                </div>
                <div class="visit-info">
                    <strong>${v.patient_name || '-'}</strong>
                    <span class="visit-time">🕐 ${v.visit_time ? v.visit_time.substring(0, 5) : 'غير محدد'}</span>
                </div>
                <div class="visit-status">
                    <span class="badge badge-green">✅ تمت</span>
                </div>
            </div>
            <div class="visit-card-body">
                <p>${v.notes || 'لا يوجد ملاحظات'}</p>
            </div>
            <div class="visit-card-footer">
                <small>📅 الزيارة القادمة: ${v.next_visit_date || 'لم تحدد بعد'}</small>
            </div>
        </div>
    `).join('');
}

function getMonthName(month) {
    const months = ['', 'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    return months[parseInt(month)] || '';
}
function searchVisits(query) {
    if (!query) { loadVisits(); return; }
    fetch(`api/search_visits.php?search=${encodeURIComponent(query)}`)
        .then(res => res.json())
        .then(data => {
            if (data.success) { renderVisits(data.data); }
        });
}
function renderToday() {
    fetch('api/get_today_visits.php')
        .then(res => res.json())
        .then(data => {
            const container = document.getElementById('today-list');
            if (!container) return;
            if (!data.success || !data.data.length) {
                container.innerHTML = '<div class="empty"><span class="icon">📅</span><p>لا يوجد زيارات اليوم</p></div>';
                return;
            }
            container.innerHTML = data.data.map(p => `
                <div class="visit-card">
                    <div class="visit-card-header">
                        <div class="visit-date-badge" style="background:var(--green);">اليوم</div>
                        <div class="visit-info">
                            <strong>${p.name}</strong>
                            <span>👨‍⚕️ ${p.doctor_name || '-'}</span>
                        </div>
                    </div>
                </div>
            `).join('');
        });
}

function renderTomorrow() {
    fetch('api/get_tomorrow_visits.php')
        .then(res => res.json())
        .then(data => {
            const container = document.getElementById('tomorrow-list');
            if (!container) return;
            
            // تحديث العنوان
            const dayNames = {'Sunday':'الأحد','Monday':'الإثنين','Tuesday':'الثلاثاء','Wednesday':'الأربعاء','Thursday':'الخميس','Friday':'الجمعة','Saturday':'السبت'};
            const dayName = dayNames[data.day_name] || data.day_name;
            document.getElementById('tomorrow-title').textContent = '📅 زيارات ' + dayName;
            document.getElementById('tomorrow-label').textContent = 'زيارات ' + dayName;
            
            if (!data.success || !data.data.length) {
                container.innerHTML = '<div class="empty"><span class="icon">🔮</span><p>لا يوجد زيارات غداً</p></div>';
                return;
            }
            container.innerHTML = data.data.map(p => `
                <div class="visit-card">
                    <div class="visit-card-header">
                        <div class="visit-date-badge" style="background:var(--accent);">غداً</div>
                        <div class="visit-info">
                            <strong>${p.name}</strong>
                            <span>👨‍⚕️ ${p.doctor_name || '-'}</span>
                        </div>
                    </div>
                </div>
            `).join('');
        });
}

// ══════════════════════════════════════
// PATIENT CRUD
// ══════════════════════════════════════
function openAddPatientModal() {
    editingId = null;
    document.getElementById('modal-title').textContent = '➕ إضافة نزيل جديد';
    document.getElementById('f-name').value = '';
    document.getElementById('f-date').value = new Date().toISOString().split('T')[0];
    document.getElementById('f-amount').value = '0';
    document.getElementById('f-paid').value = '0';
    document.getElementById('f-ref').value = '';
    document.getElementById('f-phone').value = '';
    document.getElementById('f-guardian').value = '';
    document.getElementById('f-guardian-phone').value = '';
    document.getElementById('f-diagnosis').value = '';
    document.getElementById('f-doctor').value = '';
    document.getElementById('f-notes').value = '';
    openModal('patient-modal');
}

function editPatient(id) {
    const p = patients.find(x => x.id == id);
    if (!p) return;
    editingId = id;
    document.getElementById('modal-title').textContent = '✏️ تعديل ' + p.name;
    document.getElementById('f-name').value = p.name || '';
    document.getElementById('f-date').value = p.entry_date || '';
    document.getElementById('f-amount').value = p.monthly_amount || 0;
    document.getElementById('f-paid').value = p.total_paid || 0;
    document.getElementById('f-ref').value = p.referrer_name || '';
    document.getElementById('f-phone').value = p.patient_phone || '';
    document.getElementById('f-guardian').value = p.guardian_name || '';
    document.getElementById('f-guardian-phone').value = p.guardian_phone || '';
    document.getElementById('f-diagnosis').value = p.diagnosis || '';
    document.getElementById('f-doctor').value = p.doctor_name || '';
    document.getElementById('f-notes').value = p.notes || '';
    openModal('patient-modal');
}

function savePatient() {
    const name = document.getElementById('f-name').value.trim();
    const entryDate = document.getElementById('f-date').value;
    if (!name || !entryDate) { toast('⚠️ الاسم والتاريخ مطلوبان', 'error'); return; }
    
    fetch('api/save_patient.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            id: editingId,
            name, entry_date: entryDate,
            monthly_amount: parseFloat(document.getElementById('f-amount').value) || 0,
            total_paid: parseFloat(document.getElementById('f-paid').value) || 0,
            referrer_name: document.getElementById('f-ref').value.trim(),
            patient_phone: document.getElementById('f-phone').value.trim(),
            guardian_name: document.getElementById('f-guardian').value.trim(),
            guardian_phone: document.getElementById('f-guardian-phone').value.trim(),
            diagnosis: document.getElementById('f-diagnosis').value,
            doctor_name: document.getElementById('f-doctor').value.trim(),
			cigarette_daily: parseInt(document.getElementById('f-cigarettes-daily').value) || 0,
            notes: document.getElementById('f-notes').value.trim()
        })
    })
    .then(res => res.json())
    .then(result => {
        if (result.success) { toast('✅ تم الحفظ'); closeModal('patient-modal'); loadPatients(); }
        else toast('❌ ' + (result.message || 'فشل'), 'error');
    })
    .catch(() => toast('❌ خطأ في الاتصال', 'error'));
}

function archivePatient(id) {
    fetch(`api/get_patient.php?id=${id}`)
        .then(res => res.json())
        .then(result => {
            if (result.success) {
                const p = result.data;
                
                if (p.total_debt > 0) {
                    // عرض مودال التحذير
                    document.getElementById('warning-patient-name').textContent = '👤 ' + p.name;
                    document.getElementById('warning-amount').textContent = '💰 ' + fmtNum(p.total_debt) + ' ج.م';
                    document.getElementById('confirm-archive-btn').onclick = function() {
                        doArchive(id);
                        closeModal('archive-warning-modal');
                    };
                    openModal('archive-warning-modal');
                } else {
                    if (confirm(`هل تريد أرشفة "${p.name}"؟`)) {
                        doArchive(id);
                    }
                }
            }
        });
}

function doArchive(id) {
    fetch('api/archive_patient.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
    })
    .then(res => res.json())
    .then(result => {
        if (result.success) {
            toast('📦 تمت الأرشفة بنجاح');
            loadPatients(); // ✅ دي موجودة؟
            loadDashboard(); // كمان نحدث الداشبورد
        }
    });
}
function checkAmountType() {
    const val = document.getElementById('f-amount').value.trim();
    if (val === 'دعم' || val === 'لم يحدد') {
        document.getElementById('f-amount').style.color = 'var(--accent)';
    } else {
        document.getElementById('f-amount').style.color = 'var(--text)';
    }
}
function showPatientDetail(id) {
    fetch(`api/get_patient.php?id=${id}`)
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                const p = data.data;
                
                // ══════════ الإضافات الجديدة ══════════
                const cigInfo = formatCigarettesInfo(p);
                const hasCigDebt = p.cigarette_debt > 0;
                const hasExtDebt = p.external_debt > 0;
                const hasAnyDebt = p.total_debt > 0 || hasCigDebt || hasExtDebt;
                
                let debtAlert = '';
                if (hasAnyDebt) {
                    debtAlert = `
                        <div style="background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); border-radius: 12px; padding: 14px; margin-bottom: 16px;">
                            <h4 style="color: #ef4444; margin-bottom: 10px;">⚠️ تنبيه مديونيات</h4>
                            ${p.total_debt > 0 ? `<p style="margin:4px 0;">💰 مديونية الإقامة: <strong>${fmtNum(p.total_debt)} ج</strong></p>` : ''}
                           ${(() => {
    const cigInfo = formatCigarettesInfo(p);
    const netPacks = Math.max(0, cigInfo.packs - Math.floor((p.cigarette_balance || 0) / 20));
    const netDebt = netPacks * (p.cigarette_price || 50);
    return netDebt > 0 ? `<p>🚬 مديونية السجائر: <strong>${fmtNum(netDebt)} ج</strong> (${netPacks} علبة)</p>` : '<p>🚬 مديونية السجائر: <strong style="color:#10b981;">✅ لا يوجد</strong></p>';
})()}
                            ${hasExtDebt ? `<p style="margin:4px 0;">📉 مديونية مصاريف: <strong>${fmtNum(p.external_debt)} ج</strong></p>` : ''}
                            <p style="font-size: 16px; font-weight: 900; color: #ef4444; margin-top: 8px;">
    🔴 إجمالي المديونية الكلية: ${fmtNum(Number(p.total_debt || 0) + Number(p.cigarette_debt || 0) + Number(p.external_debt || 0))} ج
</p>

                        </div>`;
                }
                
                let cigInfoHTML = '';
                if (p.cigarette_daily > 0) {
                    cigInfoHTML = `
                        <div class="detail-item"><label>🚬 السجاير اليومية</label><div class="val">${p.cigarette_daily} سيجارة</div></div>
                        <div class="detail-item"><label>📦 رصيد السجائر</label><div class="val" style="color:var(--accent);">${cigInfo.balanceText}</div></div>
                        <div class="detail-item"><label>📊 إجمالي العلب المصروفة</label><div class="val">${cigInfo.totalPacks} علبة</div></div>
                        <div class="detail-item"><label>🚬 مديونية سجائر</label><div class="val" style="color:${hasCigDebt ? 'var(--red)' : 'var(--green)'};">${hasCigDebt ? fmtNum(p.cigarette_debt) + ' ج' : '✅ لا يوجد'}</div></div>
                    `;
                }
                
                let extInfoHTML = `
                    <div class="detail-item"><label>💰 رصيد خارجي</label><div class="val" style="color:var(--green);">${fmtNum(p.external_balance || 0)} ج</div></div>
                    <div class="detail-item"><label>📉 مديونية خارجية</label><div class="val" style="color:${hasExtDebt ? 'var(--red)' : 'var(--green)'};">${hasExtDebt ? fmtNum(p.external_debt) + ' ج' : '✅ لا يوجد'}</div></div>
                `;
                // ══════════ نهاية الإضافات ══════════
                
                document.getElementById('detail-name').textContent = '👤 ' + p.name;
                document.getElementById('detail-body').innerHTML = `
                    ${debtAlert}
                    <div class="detail-grid">
                        <div class="detail-item"><label>📅 تاريخ الدخول</label><div class="val">${p.entry_date}</div></div>
						<div class="detail-item"><label>📅 مدة الإقامة</label><div class="val" style="color:var(--accent);">${p.stay_duration || p.days_stayed + ' يوم'}</div></div>
                        <div class="detail-item"><label>💰 المبلغ/شهر</label><div class="val" style="color:var(--accent);">${p.monthly_amount > 0 ? fmtNum(p.monthly_amount) + ' ج' : 'دعم كامل'}</div></div>
                        <div class="detail-item"><label>💳 إجمالي المدفوع</label><div class="val" style="color:var(--green);">${fmtNum(p.total_paid)} ج</div></div>
                        <div class="detail-item"><label>📉 المديونية</label><div class="val" style="color:${p.total_debt > 0 ? 'var(--red)' : 'var(--green)'};">${p.total_debt > 0 ? fmtNum(p.total_debt) + ' ج' : '✅ لا يوجد'}</div></div>
                        ${cigInfoHTML}
                        ${extInfoHTML}
                        <div class="detail-item"><label>⚠️ مستوى الخطر</label><div class="val">${p.risk_level === 'high' ? '🔴 خطر عالي' : p.risk_level === 'medium' ? '🟡 تنبيه' : '🟢 طبيعي'}</div></div>
                        <div class="detail-item"><label>👥 المحوِّل</label><div class="val">${p.referrer_name || '-'}</div></div>
                        <div class="detail-item"><label>🩺 التشخيص</label><div class="val">${p.diagnosis || '-'}</div></div>
                        <div class="detail-item"><label>👨‍⚕️ الطبيب</label><div class="val">${p.doctor_name || '-'}</div></div>
                        <div class="detail-item"><label>📞 هاتف النزيل</label><div class="val">${p.patient_phone || '-'}</div></div>
                        <div class="detail-item"><label>👤 ولي الأمر</label><div class="val">${p.guardian_name || '-'}</div></div>
                        <div class="detail-item"><label>📞 هاتف ولي الأمر</label><div class="val">${p.guardian_phone || '-'}</div></div>
                        <div class="detail-item" style="grid-column: span 2;"><label>📝 ملاحظات</label><div class="val">${p.notes || 'لا يوجد'}</div></div>
                    </div>
                `;
                openModal('detail-modal');
            }
        });
}
function deleteAllVisits() {
    if (!confirm('⚠️ هل أنت متأكد من حذف جميع الزيارات؟ هذا الإجراء لا يمكن التراجع عنه!')) return;
    
    if (!confirm('تأكيد نهائي: سيتم حذف كل الزيارات المسجلة. متابعة؟')) return;
    
    fetch('api/delete_all_visits.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                toast('🗑️ تم حذف ' + data.deleted + ' زيارة');
                loadVisits();
            } else {
                toast('❌ ' + data.message, 'error');
            }
        });
}
// ══════════════════════════════════════
// PAYMENT
// ══════════════════════════════════════
function openPaymentModal() {
    document.getElementById('p-date').value = new Date().toISOString().split('T')[0];
    document.getElementById('p-amount').value = '';
    document.getElementById('p-from').value = '';
    document.getElementById('p-notes').value = '';
    document.getElementById('p-patient').innerHTML = '<option value="">— اختر —</option>' + patients.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
    openModal('payment-modal');
}

function openPaymentForPatient(id) {
    openPaymentModal();
    document.getElementById('p-patient').value = id;
}

function savePayment() {
    const patientId = document.getElementById('p-patient').value;
    const amount = document.getElementById('p-amount').value;
    if (!patientId || !amount) { toast('⚠️ اختر النزيل والمبلغ', 'error'); return; }
    
    fetch('api/add_payment.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            patient_id: patientId,
            amount: parseFloat(amount),
            payment_date: document.getElementById('p-date').value,
            payment_method: document.getElementById('p-method').value,
            received_from: document.getElementById('p-from').value,
            notes: document.getElementById('p-notes').value
        })
    })
    .then(res => res.json())
    .then(result => {
        if (result.success) { toast('✅ تم'); closeModal('payment-modal'); loadPatients(); loadPayments(); }
        else toast('❌ ' + (result.message || 'فشل'), 'error');
    })
    .catch(() => toast('❌ خطأ', 'error'));
}

// ══════════════════════════════════════
// VISIT
// ══════════════════════════════════════
function openVisitModal() {
    document.getElementById('v-date').value = new Date().toISOString().split('T')[0];
    document.getElementById('v-time').value = '';
    document.getElementById('v-notes').value = '';
    document.getElementById('v-patient').innerHTML = '<option value="">— اختر —</option>' + patients.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
    openModal('visit-modal');
}

function saveVisit() {
    const patientId = document.getElementById('v-patient').value;
    if (!patientId) { toast('⚠️ اختر النزيل', 'error'); return; }
    
    fetch('api/add_visit.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            patient_id: patientId,
            visit_date: document.getElementById('v-date').value,
            visit_time: document.getElementById('v-time').value,
            notes: document.getElementById('v-notes').value
        })
    })
    .then(res => res.json())
    .then(result => {
        if (result.success) { toast('✅ تم'); closeModal('visit-modal'); }
        else toast('❌ ' + (result.message || 'فشل'), 'error');
    })
    .catch(() => toast('❌ خطأ', 'error'));
}

// ══════════════════════════════════════
// LATE, ARCHIVE, REFERRERS
// ══════════════════════════════════════
function renderLate() {
    fetch('api/get_late.php')
        .then(res => res.json())
        .then(data => {
            const tbody = document.getElementById('late-body');
            if (!tbody) return;
            if (!data.success || !data.data.length) {
                tbody.innerHTML = '<tr><td colspan="6"><div class="empty">✅ لا يوجد متأخرون</div></td></tr>';
                return;
            }
            tbody.innerHTML = data.data.map((p, i) => `
                <tr onclick="showPatientDetail(${p.id})" style="cursor:pointer;">
                   <td>${i+1}</td>
<td class="td-name">${p.name}</td>
<td class="td-date">${p.entry_date}</td>
<td style="color:var(--yellow);font-weight:700;">${p.overdue_months} شهر ${p.overdue_days} يوم</td>
<td>${p.referrer_name || '-'}</td>
                </tr>
            `).join('');
        });
}
function renderArchive() {
    fetch('api/get_archive.php')
        .then(res => res.json())
        .then(data => {
            const tbody = document.getElementById('archive-body');
            if (!tbody) return;
            if (!data.success || !data.data.length) {
                tbody.innerHTML = '<tr><td colspan="6"><div class="empty">📦 الأرشيف فارغ</div></td></tr>';
                return;
            }
            tbody.innerHTML = data.data.map((p, i) => `
                <tr><td>${i+1}</td><td>${p.name}</td><td>${p.entry_date}</td><td>${p.exit_date||'-'}</td><td>${fmtNum(p.total_paid)} ج</td><td>${p.total_debt>0?fmtNum(p.total_debt)+' ج':'✅'}</td></tr>
            `).join('');
        });
}

function renderReferrers() {
    fetch('api/get_referrers.php')
        .then(res => res.json())
        .then(data => {
            const tbody = document.getElementById('referrers-body');
            if (!tbody) return;
            if (!data.success || !data.data.length) {
                tbody.innerHTML = '<tr><td colspan="6"><div class="empty">👥 لا يوجد</div></td></tr>';
                return;
            }
            tbody.innerHTML = data.data.map((r, i) => {
                const total = parseFloat(r.total_paid) + parseFloat(r.total_debt);
                const rate = total > 0 ? ((parseFloat(r.total_paid) / total) * 100).toFixed(1) : 0;
                return `<tr><td>${i+1}</td><td><strong>${r.name||'-'}</strong></td><td>${r.patient_count}</td><td>${fmtNum(r.total_paid)} ج</td><td>${r.total_debt>0?fmtNum(r.total_debt)+' ج':'✅'}</td><td>${rate}%</td></tr>`;
            }).join('');
        });
}
// ══════════════════════════════════════
// CONSUMABLES - السجائر والمصاريف
// ══════════════════════════════════════

function loadConsumables() {
    fetch('api/get_consumables.php')
        .then(res => res.json())
        .then(data => {
            const tbody = document.getElementById('consumables-body');
            if (!tbody) return;
            if (!data.success || !data.data.length) {
                tbody.innerHTML = '<tr><td colspan="5"><div class="empty"><span class="icon">🚬</span><p>لا يوجد نزلاء</p></div></td></tr>';
                return;
            }
    tbody.innerHTML = data.data.map(p => {
    const daily = p.cigarette_daily || 0;
    const days = p.days_stayed || 0;
    const totalUsed = daily * days;
    const packsUsed = Math.floor(totalUsed / 20);
    const singlesUsed = totalUsed % 20;
    const balanceCig = p.cigarette_balance || 0;
    const balancePacks = Math.floor(balanceCig / 20);
    const netPacks = Math.max(0, packsUsed - balancePacks);
    const cigDebt = netPacks * 50;
    const extDebt = parseFloat(p.external_debt) || 0;
   const totalNetDebt = (cigDebt + extDebt) - (parseFloat(p.external_balance) || 0);
    
    return `
        <tr>
            <td style="font-weight:600;">${p.name}</td>
            <td>
    <span class="badge badge-green">🚬 ${balanceCig > 0 ? balanceCig + ' س (' + balancePacks + ' ع)' : '0'}</span>
    ${balanceCig > 0 ? `<br><small style="color:#10b981;font-weight:700;">${fmtNum(balancePacks * 50)} ج</small>` : ''}
</td>
            <td>
    <span class="badge badge-red">📊 ${totalUsed} س (${packsUsed} ع${singlesUsed > 0 ? ' + ' + singlesUsed + ' س' : ''})</span>
    <br><small style="color:#ef4444;font-weight:700;">${fmtNum(packsUsed * 50)} ج</small>
</td>
            <td><span class="badge badge-red">📉 ${fmtNum(extDebt)} ج</span></td>
            <td><span class="badge" style="background:rgba(16,185,129,0.12);color:#10b981;border:1px solid rgba(16,185,129,0.2);">💰 ${fmtNum(p.external_balance || 0)} ج</span></td>
            <td><span class="badge ${totalNetDebt > 0 ? 'badge-red' : 'badge-green'}">${totalNetDebt > 0 ? '📉 ' + totalNetDebt + ' ج' : '✅ مسدد'}</span></td>
            <td>
                <button class="btn btn-primary btn-sm" onclick="openConsumableModal(${p.id})">🚬 إدارة</button>
                <button class="btn btn-ghost btn-sm" onclick="loadTransactions(${p.id});openModal('transactions-modal')">📋 سجل</button>
            </td>
        </tr>
    `;
}).join('');
        });
}

function openConsumableModal(patientId) {
    document.getElementById('c-patient-id').value = patientId;
    
    fetch(`api/get_patient.php?id=${patientId}`)
        .then(res => res.json())
        .then(result => {
            if (result.success) {
                const p = result.data;
                document.getElementById('c-cig-balance').textContent = p.cigarette_balance || 0;
                document.getElementById('c-ext-balance').textContent = fmtNum(p.external_balance || 0) + ' ج';
                document.getElementById('c-ext-debt').textContent = fmtNum(p.external_debt || 0) + ' ج';
                
                // المربع الرابع - عليه سجائر
                var totalS = (parseInt(p.cigarette_daily) || 0) * (parseInt(p.days_stayed) || 0);
                var packsS = Math.floor(totalS / 20);
                var debtS = packsS * 50;
                document.getElementById('c-center-cig').textContent = totalS + ' س (' + packsS + ' ع) - ' + debtS + ' ج';
                
                document.getElementById('consumable-title').textContent = '🚬 ' + p.name;
            }
        });
    
    document.getElementById('tab-cigarettes').style.display = 'block';
    document.getElementById('tab-external').style.display = 'none';
    document.querySelectorAll('.tab').forEach((t, i) => { t.classList.toggle('active', i === 0); });
    document.getElementById('c-qty').value = '';
    document.getElementById('c-notes').value = '';
    document.getElementById('e-amount').value = '';
    document.getElementById('e-notes').value = '';
    
    openModal('consumable-modal');
    loadTransactions(patientId);
}

function switchConsumableTab(tab) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    event.target.classList.add('active');
    document.getElementById('tab-cigarettes').style.display = tab === 'cigarettes' ? 'block' : 'none';
    document.getElementById('tab-external').style.display = tab === 'external' ? 'block' : 'none';
}

function saveCigaretteTransaction() {
    const patientId = document.getElementById('c-patient-id').value;
    const type = document.getElementById('c-type').value;
    const qty = parseInt(document.getElementById('c-qty').value) || 0;
    const notes = document.getElementById('c-notes').value;
    
    if (!qty) {
        toast('⚠️ أدخل الكمية', 'error');
        return;
    }
    
    fetch('api/save_transaction.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            patient_id: patientId,
            type: 'cigarettes',
            quantity: type === 'add' ? qty : -qty,
            notes: notes
        })
    })
    .then(res => res.json())
    .then(result => {
        if (result.success) {
            toast('✅ تم تسجيل السجائر بنجاح');
            closeModal('consumable-modal');
            loadConsumables();
        } else {
            toast('❌ ' + (result.message || 'فشل'), 'error');
        }
    });
}

function saveExternalTransaction() {
    const patientId = document.getElementById('c-patient-id').value;
    const type = document.getElementById('e-type').value;
    const amount = parseFloat(document.getElementById('e-amount').value) || 0;
    const notes = document.getElementById('e-notes').value;
    
    if (!amount) {
        toast('⚠️ أدخل المبلغ', 'error');
        return;
    }
    
    fetch('api/save_transaction.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            patient_id: patientId,
            type: type,
            amount: amount,
            notes: notes
        })
    })
    .then(res => res.json())
    .then(result => {
        if (result.success) {
            toast('✅ تم تسجيل المعاملة بنجاح');
            closeModal('consumable-modal');
            loadConsumables();
        } else {
            toast('❌ ' + (result.message || 'فشل'), 'error');
        }
    });
}
function formatCigarettesInfo(p) {
    const daily = parseInt(p.cigarette_daily) || 0;
    const days = parseInt(p.days_stayed) || 0;
    const totalUsed = daily * days;
    const packs = Math.floor(totalUsed / 20);
    const singles = totalUsed % 20;
    const debt = packs * (parseInt(p.cigarette_price) || 50);
    const balance = parseInt(p.cigarette_balance) || 0;
    
    let balanceText = '0';
    if (balance > 0) {
        const balancePacks = Math.floor(balance / 20);
        const balanceSingles = balance % 20;
        balanceText = balancePacks + ' ع' + (balanceSingles > 0 ? ' + ' + balanceSingles + ' س' : '');
    }
    
    return {
        daily: daily,
        days: days,
        totalUsed: totalUsed,
        packs: packs,
        singles: singles,
        balance: balance,
        debt: debt,
        balanceText: balanceText,
        packsText: packs + ' علبة' + (singles > 0 ? ' + ' + singles + ' سيجارة' : ''),
        totalPacks: packs
    };
}
function updateMonthlyCigaretteDebt() {
    if (!confirm('سيتم تحديث مديونية السجائر لجميع النزلاء حسب استهلاكهم الشهري. متابعة؟')) return;
    
    fetch('api/update_cigarette_debt.php')
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                toast('✅ تم تحديث ' + data.updated + ' نزيل');
                loadConsumables();
            }
        });
}
// ══════════════════════════════════════
// SEARCH & FILTER
// ══════════════════════════════════════
function searchPatients(query) {
    fetch(`api/get_patients.php?search=${encodeURIComponent(query)}`)
        .then(res => res.json())
        .then(data => { if (data.success) { patients = data.data; renderPatients(); } });
}

function filterPatients(risk) {
    fetch(`api/get_patients.php?risk=${risk}`)
        .then(res => res.json())
        .then(data => { if (data.success) { patients = data.data; renderPatients(); } });
}
// ضمان إن الزراير شغالة
function calculateMonthlyCigarettes() {
    const daily = parseInt(document.getElementById('f-cigarettes-daily').value) || 0;
    const monthly = daily * 30;
    const packs = monthly / 20;
    
    if (packs % 1 === 0) {
        document.getElementById('f-cigarettes-monthly').value = packs + ' علبة';
    } else {
        const wholePacks = Math.floor(packs);
        const remaining = Math.round((packs - wholePacks) * 20);
        document.getElementById('f-cigarettes-monthly').value = wholePacks + ' علبة و ' + remaining + ' سيجارة';
    }
}
function loadTransactions(patientId) {
    fetch(`api/get_transactions.php?patient_id=${patientId}`)
        .then(res => res.json())
        .then(data => {
            const container = document.getElementById('transactions-list');
            if (!container) return;
            
            if (!data.success || !data.data.length) {
                container.innerHTML = '<p style="color:var(--text3);text-align:center;padding:20px;">لا توجد معاملات</p>';
                return;
            }
            
            container.innerHTML = `
                <table style="width:100%;border-collapse:collapse;">
                    <thead>
                        <tr style="border-bottom:1px solid var(--border);">
                            <th style="padding:8px;text-align:right;">النوع</th>
                            <th style="padding:8px;text-align:right;">الكمية/المبلغ</th>
                            <th style="padding:8px;text-align:right;">ملاحظات</th>
                            <th style="padding:8px;text-align:right;">التاريخ</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${data.data.map(t => {
                            let typeIcon = '📋';
                            let typeName = 'أخرى';
                            let value = '';
                            
                            if (t.type === 'cigarettes') {
                                typeIcon = t.quantity > 0 ? '➕' : '➖';
                                typeName = t.quantity > 0 ? 'إضافة سجائر' : 'صرف سجائر';
                                value = Math.abs(t.quantity) + ' سيجارة';
                            } else if (t.type === 'deposit') {
                                typeIcon = '💰';
                                typeName = 'إيداع مبلغ';
                                value = fmtNum(t.amount) + ' ج';
                            } else if (t.type === 'external_expense') {
                                typeIcon = '💸';
                                typeName = 'صرف مبلغ';
                                value = fmtNum(t.amount) + ' ج';
                            } else if (t.type === 'charge') {
                                typeIcon = '📋';
                                typeName = 'مديونية';
                                value = fmtNum(t.amount) + ' ج';
                            }
                            
                            return `
                                <tr style="border-bottom:1px solid var(--border);">
                                    <td style="padding:8px;">${typeIcon} ${typeName}</td>
                                    <td style="padding:8px;font-weight:700;">${value}</td>
                                    <td style="padding:8px;color:var(--text2);">${t.notes || '-'}</td>
                                    <td style="padding:8px;font-size:12px;color:var(--text3);">${t.created_at ? t.created_at.substring(0, 16) : '-'}</td>
                                </tr>
                            `;
                        }).join('')}
                    </tbody>
                </table>
            `;
        });
}
// ══════════════════════════════════════
// INIT
// ══════════════════════════════════════
