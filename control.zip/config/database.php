<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);
/**
 * ملف الاتصال بقاعدة البيانات
 * Database Connection
 */

$host = 'localhost';        // السيرفر
$dbname = 'u727762592_almashfacon';    // اسم قاعدة البيانات
$username = 'u727762592_momen';         // اسم المستخدم الافتراضي في XAMPP
$password = 'Elgazar100%';             // كلمة المرور الافتراضية فاضية في XAMPP

try {
    // إنشاء اتصال PDO
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        ]
    );
} catch(PDOException $e) {
    // لو فشل الاتصال
    die("❌ فشل الاتصال بقاعدة البيانات: " . $e->getMessage());
}
?>