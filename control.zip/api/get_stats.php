<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

try {
    $totalCollected = $pdo->query("SELECT COALESCE(SUM(total_paid), 0) FROM patients WHERE status='active'")->fetchColumn();
    $totalDebt = $pdo->query("SELECT COALESCE(SUM(total_debt), 0) FROM patients WHERE status='active'")->fetchColumn();

    echo json_encode([
        'success' => true,
        'total_collected' => (int)$totalCollected,
        'total_debt' => (int)$totalDebt
    ]);
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>