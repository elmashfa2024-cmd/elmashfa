<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$search = $_GET['search'] ?? '';
$risk = $_GET['risk'] ?? '';
$referrer = $_GET['referrer'] ?? '';

$query = "SELECT * FROM patients WHERE status='active'";
$params = [];

// فلتر المحول - لو فيه referrer، نجيب نزلاءه فقط
if (!empty($referrer)) {
    $query .= " AND referrer_name = ?";
    $params[] = $referrer;
}

if ($search) {
    $query .= " AND name LIKE ?";
    $params[] = "%{$search}%";
}

if ($risk) {
    if ($risk === 'paid') {
        $query .= " AND total_debt = 0";
    } else {
        $query .= " AND risk_level = ?";
        $params[] = $risk;
    }
}

$query .= " ORDER BY id DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$patients = $stmt->fetchAll();

echo json_encode(['success' => true, 'data' => $patients]);
?>