<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$patientId = $_GET['patient_id'] ?? 0;

$stmt = $pdo->prepare("SELECT * FROM patient_transactions WHERE patient_id = ? ORDER BY created_at DESC");
$stmt->execute([$patientId]);
$transactions = $stmt->fetchAll();

echo json_encode(['success' => true, 'data' => $transactions]);
?>