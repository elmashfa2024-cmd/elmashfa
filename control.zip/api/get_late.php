<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$late = $pdo->query("
    SELECT *, 
        (total_debt + cigarette_debt + external_debt - external_balance) AS net_debt
    FROM patients 
    WHERE status='active' AND (total_debt > 0 OR cigarette_debt > 0 OR external_debt > 0)
    ORDER BY net_debt DESC
")->fetchAll();

echo json_encode(['success' => true, 'data' => $late]);
?>