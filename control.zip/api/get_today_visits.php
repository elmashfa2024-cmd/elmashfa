<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$today = date('Y-m-d');
$visits = $pdo->prepare("
    SELECT p.id, p.name, p.next_visit_date, p.room_number, p.doctor_name
    FROM patients p
    WHERE p.next_visit_date = ? AND p.status = 'active'
    ORDER BY p.name
");
$visits->execute([$today]);
echo json_encode(['success' => true, 'data' => $visits->fetchAll()]);
?>