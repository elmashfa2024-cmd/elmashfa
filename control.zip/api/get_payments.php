<?php

header('Content-Type: application/json; charset=utf-8');



require_once '../config/database.php';

$payments = $pdo->query("
    SELECT p.*, pt.name as patient_name
    FROM payments p
    JOIN patients pt ON p.patient_id = pt.id
    ORDER BY p.payment_date DESC, p.id DESC
    LIMIT 50
")->fetchAll();

echo json_encode(['success' => true, 'data' => $payments]);
?>