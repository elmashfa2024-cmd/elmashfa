<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$data = json_decode(file_get_contents('php://input'), true);

$patientId = $data['patient_id'] ?? 0;
$type = $data['type'] ?? '';
$qty = intval($data['quantity'] ?? 0);
$amount = floatval($data['amount'] ?? 0);
$notes = $data['notes'] ?? '';

if (!$patientId) {
    echo json_encode(['success' => false, 'message' => 'رقم النزيل مطلوب']);
    exit;
}

try {
    // ══════════ سجائر ══════════
    if ($type === 'cigarettes') {
        if ($qty > 0) {
            // الأهل ضافوا سجائر → نزود الرصيد ونخصم من المديونية
            $packsAdded = floor($qty / 20);
            $debtReduction = $packsAdded * 50;
            
            $pdo->prepare("UPDATE patients SET 
                cigarette_balance = cigarette_balance + ?,
                cigarette_debt = GREATEST(0, cigarette_debt - ?),
                cigarette_debt_packs = GREATEST(0, cigarette_debt_packs - ?)
                WHERE id = ?")->execute([$qty, $debtReduction, $packsAdded, $patientId]);
        } else {
            // صرف سجائر للنزيل → يقلل من رصيده
            $pdo->prepare("UPDATE patients SET cigarette_balance = cigarette_balance + ? WHERE id = ?")->execute([$qty, $patientId]);
        }
        
        $pdo->prepare("INSERT INTO patient_transactions (patient_id, type, quantity, notes) VALUES (?, 'cigarettes', ?, ?)")->execute([$patientId, $qty, $notes]);
        echo json_encode(['success' => true, 'message' => 'تم تسجيل السجائر']);
    
    // ══════════ إيداع ══════════
    } elseif ($type === 'deposit') {
        $pdo->prepare("UPDATE patients SET external_balance = external_balance + ? WHERE id = ?")->execute([$amount, $patientId]);
        $pdo->prepare("INSERT INTO patient_transactions (patient_id, type, amount, notes) VALUES (?, 'deposit', ?, ?)")->execute([$patientId, $amount, $notes]);
        echo json_encode(['success' => true, 'message' => 'تم الإيداع']);
    
    // ══════════ صرف ══════════
    } elseif ($type === 'expense') {
        $stmt = $pdo->prepare("SELECT external_balance FROM patients WHERE id = ?");
        $stmt->execute([$patientId]);
        $balance = $stmt->fetchColumn();
        
        if ($balance < $amount) {
            echo json_encode(['success' => false, 'message' => 'عفواً، لا يوجد رصيد كافي. الرصيد: ' . number_format($balance, 2) . ' ج']);
            exit;
        }
        
        $pdo->prepare("UPDATE patients SET external_balance = external_balance - ? WHERE id = ?")->execute([$amount, $patientId]);
        $pdo->prepare("INSERT INTO patient_transactions (patient_id, type, amount, notes) VALUES (?, 'external_expense', ?, ?)")->execute([$patientId, $amount, $notes]);
        echo json_encode(['success' => true, 'message' => 'تم الصرف']);
    
    // ══════════ مديونية ══════════
    } elseif ($type === 'charge') {
        $pdo->prepare("UPDATE patients SET external_debt = external_debt + ? WHERE id = ?")->execute([$amount, $patientId]);
        $pdo->prepare("INSERT INTO patient_transactions (patient_id, type, amount, notes) VALUES (?, 'charge', ?, ?)")->execute([$patientId, $amount, $notes]);
        echo json_encode(['success' => true, 'message' => 'تم تسجيل المديونية']);
    }
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>