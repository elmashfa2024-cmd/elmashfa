<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

try {
    // حذف كل الزيارات
    $stmt = $pdo->query("SELECT COUNT(*) FROM visits");
    $count = $stmt->fetchColumn();
    $pdo->query("DELETE FROM visits");
    
    // مسح مواعيد الزيارات القادمة من النزلاء
    $pdo->query("UPDATE patients SET next_visit_date = NULL");
    
    echo json_encode(['success' => true, 'deleted' => $count, 'message' => 'تم حذف جميع الزيارات ومواعيد الزيارات القادمة']);
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>