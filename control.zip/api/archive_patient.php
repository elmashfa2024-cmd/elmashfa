<?php

header('Content-Type: application/json; charset=utf-8');


require_once '../config/database.php';

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'] ?? 0;

$stmt = $pdo->prepare("UPDATE patients SET status='archived', exit_date=CURDATE() WHERE id=?");
$stmt->execute([$id]);

echo json_encode(['success' => true, 'message' => 'تم الأرشفة']);
?>