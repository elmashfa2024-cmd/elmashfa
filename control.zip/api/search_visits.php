<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$search = $_GET['search'] ?? '';

$stmt = $pdo->prepare("
    SELECT v.*, p.name as patient_name, p.next_visit_date
    FROM visits v
    JOIN patients p ON v.patient_id = p.id
    WHERE p.name LIKE ?
    ORDER BY v.visit_date DESC
    LIMIT 20
");
$stmt->execute(["%{$search}%"]);
$visits = $stmt->fetchAll();

echo json_encode(['success' => true, 'data' => $visits]);
?>