<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$id = $_GET['id'] ?? 0;

if (empty($id)) {
    echo json_encode(['error' => 'رقم النزيل غير صحيح']);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM patients WHERE id = ?");
$stmt->execute([$id]);
$patient = $stmt->fetch();

if ($patient) {
    // حساب مدة الإقامة لكل النزلاء
    if (!empty($patient['entry_date']) && $patient['entry_date'] != '0000-00-00') {
        $entryDate = new DateTime($patient['entry_date']);
        $today = new DateTime();
        $daysDiff = $today->diff($entryDate)->days;
        $patient['days_stayed'] = $daysDiff;
        $patient['months_stayed'] = floor($daysDiff / 30);
        $patient['remaining_days'] = $daysDiff % 30;
        $patient['stay_duration'] = $daysDiff . ' يوم' . ($daysDiff >= 30 ? ' (' . floor($daysDiff/30) . ' شهر و ' . $daysDiff%30 . ' يوم)' : '');
    } else {
        $patient['days_stayed'] = 0;
        $patient['stay_duration'] = 'غير محدد';
    }
    
    // حساب السجاير (لو بياخد)
    if ($patient['cigarette_daily'] > 0 && isset($patient['days_stayed'])) {
        $totalCigarettes = $patient['cigarette_daily'] * $patient['days_stayed'];
        $totalPacks = floor($totalCigarettes / 20);
        $cigarettePrice = $patient['cigarette_price'] ?? 50;
        $cigaretteDebt = $totalPacks * $cigarettePrice;
        $patient['cigarette_debt_packs'] = $totalPacks;
        $patient['cigarette_debt'] = $cigaretteDebt;
        $patient['total_cigarettes_used'] = $totalCigarettes;
        $patient['total_packs_used'] = $totalPacks;
    }
    
    echo json_encode(['success' => true, 'data' => $patient]);
} else {
    echo json_encode(['error' => 'النزيل غير موجود']);
}
?>