<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$referrer = $_GET['referrer'] ?? '';

try {
    if (!empty($referrer)) {
        // إحصائيات المحول
        $totalPatients = $pdo->prepare("SELECT COUNT(*) FROM patients WHERE status='active' AND referrer_name=?");
        $totalPatients->execute([$referrer]);
        $totalPatients = $totalPatients->fetchColumn();
        
        $totalDebt = $pdo->prepare("SELECT COALESCE(SUM(total_debt), 0) FROM patients WHERE status='active' AND referrer_name=?");
        $totalDebt->execute([$referrer]);
        $totalDebt = $totalDebt->fetchColumn();
        
        echo json_encode([
            'success' => true,
            'stats' => [
                'total_patients' => (int)$totalPatients,
                'total_debt' => (int)$totalDebt,
                'paid_count' => 0,
                'late_count' => 0,
                'danger_count' => 0,
                'archived_count' => 0,
                'today_visits' => 0
            ]
        ]);
    } else {
        // إحصائيات المدير
        $totalPatients = $pdo->query("SELECT COUNT(*) FROM patients WHERE status='active'")->fetchColumn();
        $totalDebt = $pdo->query("SELECT COALESCE(SUM(total_debt), 0) FROM patients WHERE status='active'")->fetchColumn();
        $paidCount = $pdo->query("SELECT COUNT(*) FROM patients WHERE status='active' AND total_debt=0")->fetchColumn();
        $lateCount = $pdo->query("SELECT COUNT(*) FROM patients WHERE status='active' AND total_debt>0 AND risk_level IN ('high','medium')")->fetchColumn();
        $dangerCount = $pdo->query("SELECT COUNT(*) FROM patients WHERE status='active' AND risk_level='high'")->fetchColumn();
        $todayVisits = $pdo->query("SELECT COUNT(*) FROM patients WHERE next_visit_date = CURDATE() AND status='active'")->fetchColumn();
        $archivedCount = $pdo->query("SELECT COUNT(*) FROM patients WHERE status='archived'")->fetchColumn();

        echo json_encode([
            'success' => true,
            'stats' => [
                'total_patients' => (int)$totalPatients,
                'total_debt' => (int)$totalDebt,
                'paid_count' => (int)$paidCount,
                'late_count' => (int)$lateCount,
                'danger_count' => (int)$dangerCount,
                'today_visits' => (int)$todayVisits,
                'archived_count' => (int)$archivedCount
            ]
        ]);
    }
} catch(Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>