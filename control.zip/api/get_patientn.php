<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$id = $_GET['id'] ?? 0;

if (empty($id)) {
    echo json_encode(['error' => 'رقم النزيل غير صحيح']);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM patients WHERE id = ?");
$stmt->execute([$id]);
$patient = $stmt->fetch();

if ($patient) {
    // حساب السجاير اليومية
    if ($patient['cigarette_daily'] > 0) {
        $entryDate = new DateTime($patient['entry_date']);
        $today = new DateTime();
        $daysDiff = $today->diff($entryDate)->days;
        
        $totalCigarettes = $patient['cigarette_daily'] * $daysDiff;
        $totalPacks = floor($totalCigarettes / 20);
		$patient['cigarette_debt_packs'] = $totalPacks;
$patient['cigarette_debt'] = $cigaretteDebt;
        $remainingSingles = $totalCigarettes % 20;
        
        $cigarettePrice = $patient['cigarette_price'] ?? 50;
        $cigaretteDebt = $totalPacks * $cigarettePrice;
        $cigaretteBalance = $patient['cigarette_balance'] ?? 0;
        
        $patient['total_cigarettes_used'] = $totalCigarettes;
        $patient['total_packs_used'] = $totalPacks;
        $patient['remaining_singles'] = $remainingSingles;
        $patient['cigarette_debt'] = $cigaretteDebt;
        $patient['cigarette_balance'] = $cigaretteBalance;
        $patient['days_stayed'] = $daysDiff;
		$patient['days_stayed'] = $daysDiff;
$patient['months_stayed'] = floor($daysDiff / 30);
$patient['remaining_days'] = $daysDiff % 30;
$patient['stay_duration'] = $daysDiff . ' يوم' . ($daysDiff >= 30 ? ' (' . floor($daysDiff/30) . ' شهر و ' . $daysDiff%30 . ' يوم)' : '');
    }
    if ($patient['cigarette_daily'] > 0) {
    $entryDate = new DateTime($patient['entry_date']);
    $today = new DateTime();
    $daysDiff = $today->diff($entryDate)->days;
    $patient['days_stayed'] = $daysDiff;
}
    echo json_encode(['success' => true, 'data' => $patient]);
} else {
    echo json_encode(['error' => 'النزيل غير موجود']);
}
?>