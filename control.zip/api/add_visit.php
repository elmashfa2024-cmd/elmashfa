<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$data = json_decode(file_get_contents('php://input'), true);

$patientId = $data['patient_id'] ?? 0;
$visitDate = $data['visit_date'] ?? date('Y-m-d');
$visitTime = $data['visit_time'] ?? null;
$notes = $data['notes'] ?? '';
if ($visitTime && strlen($visitTime) === 5) {
    $visitTime .= ':00'; // نخلي 4:00 → 4:00:00
}
if (!$patientId) {
    echo json_encode(['success' => false, 'message' => 'اختر النزيل']);
    exit;
}

try {
    $stmt = $pdo->prepare("INSERT INTO visits (patient_id, specialist_id, visit_date, visit_time, notes) VALUES (?, 1, ?, ?, ?)");
    $stmt->execute([$patientId, $visitDate, $visitTime, $notes]);
	// تحديث موعد الزيارة القادمة بعد 15 يوم
$nextVisit = date('Y-m-d', strtotime($visitDate . ' +15 days'));
$pdo->prepare("UPDATE patients SET next_visit_date=? WHERE id=?")->execute([$nextVisit, $patientId]);
    
    echo json_encode(['success' => true, 'message' => 'تم تسجيل الزيارة']);
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>