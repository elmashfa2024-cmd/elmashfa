<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

try {
    $referrers = $pdo->query("
        SELECT 
            COALESCE(NULLIF(referrer_name,''), '-') as name,
            COUNT(*) as patient_count,
            COALESCE(SUM(total_paid), 0) as total_paid,
            COALESCE(SUM(total_debt), 0) as total_debt
        FROM patients WHERE status='active'
        GROUP BY referrer_name
        ORDER BY patient_count DESC
    ")->fetchAll();

    echo json_encode(['success' => true, 'data' => $referrers]);
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>