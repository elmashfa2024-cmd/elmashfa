<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$data = json_decode(file_get_contents('php://input'), true);

$id = $data['id'] ?? null;
$name = $data['name'] ?? '';
$entryDate = $data['entry_date'] ?? '';
$monthlyAmountRaw = $data['monthly_amount'] ?? '0';
$monthlyAmount = is_numeric($monthlyAmountRaw) ? $monthlyAmountRaw : 0;
$monthlyType = is_numeric($monthlyAmountRaw) ? 'fixed' : $monthlyAmountRaw;
$totalPaid = $data['total_paid'] ?? 0;
$cigaretteDaily = isset($data['cigarette_daily']) ? intval($data['cigarette_daily']) : 0;
$cigarettePrice = $data['cigarette_price'] ?? 50;
$cigaretteBalance = 0;
$cigaretteMonthlyPacks = ceil($cigaretteDaily * 30 / 20);
$cigaretteDebt = $cigaretteMonthlyPacks * $cigarettePrice;
$cigaretteTotalPacks = $cigaretteMonthlyPacks;
$referrerName = $data['referrer_name'] ?? '';
$patientPhone = $data['patient_phone'] ?? '';
$guardianName = $data['guardian_name'] ?? '';
$guardianPhone = $data['guardian_phone'] ?? '';
$diagnosis = $data['diagnosis'] ?? '';
$doctorName = $data['doctor_name'] ?? '';
$notes = $data['notes'] ?? '';

if (empty($name) || empty($entryDate)) {
    echo json_encode(['success' => false, 'message' => 'الاسم والتاريخ مطلوبان']);
    exit;
}

$entryDateTime = new DateTime($entryDate);
$now = new DateTime();
$monthsDiff = ($now->diff($entryDateTime)->days) / 30;
$expectedTotal = $monthlyAmount * $monthsDiff;
$totalDebt = max(0, $expectedTotal - $totalPaid);

if ($totalDebt == 0) {
    $riskLevel = 'low';
} elseif ($monthlyAmount > 0 && ($totalDebt / $monthlyAmount) >= 6) {
    $riskLevel = 'high';
} elseif ($monthlyAmount > 0 && ($totalDebt / $monthlyAmount) >= 3) {
    $riskLevel = 'medium';
} else {
    $riskLevel = 'low';
}

try {
    $overdueMonths = 0;
    $overdueDays = 0;
    if ($totalDebt > 0 && $monthlyAmount > 0) {
        $overdueMonths = floor($totalDebt / $monthlyAmount);
        $overdueDays = round(($totalDebt / $monthlyAmount - $overdueMonths) * 30);
    }
    
    if ($id) {
        $stmt = $pdo->prepare("
            UPDATE patients SET 
            name=?, entry_date=?, monthly_amount=?, monthly_type=?, total_paid=?, total_debt=?,
            cigarette_daily=?, cigarette_price=?, cigarette_balance=?, 
            cigarette_debt=?, cigarette_debt_packs=?, cigarette_total_packs=?,
            cigarette_last_update=CURDATE(),
            risk_level=?, overdue_months=?, overdue_days=?, 
            referrer_name=?, patient_phone=?, guardian_name=?, guardian_phone=?,
            diagnosis=?, doctor_name=?, notes=?
            WHERE id=?
        ");
        $stmt->execute([
            $name, $entryDate, $monthlyAmount, $monthlyType, $totalPaid, $totalDebt,
            $cigaretteDaily, $cigarettePrice, $cigaretteBalance,
            $cigaretteDebt, $cigaretteMonthlyPacks, $cigaretteTotalPacks,
            $riskLevel, $overdueMonths, $overdueDays,
            $referrerName, $patientPhone, $guardianName, $guardianPhone,
            $diagnosis, $doctorName, $notes, $id
        ]);
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO patients (
                name, entry_date, monthly_amount, monthly_type, total_paid, total_debt, 
                risk_level, overdue_months, overdue_days, 
                cigarette_daily, cigarette_price, cigarette_balance, 
                cigarette_debt, cigarette_debt_packs, cigarette_total_packs, cigarette_last_update,
                referrer_name, patient_phone, guardian_name, guardian_phone, 
                diagnosis, doctor_name, notes
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $name, $entryDate, $monthlyAmount, $monthlyType, $totalPaid, $totalDebt, 
            $riskLevel, $overdueMonths, $overdueDays, 
            $cigaretteDaily, $cigarettePrice, $cigaretteBalance, 
            $cigaretteDebt, $cigaretteMonthlyPacks, $cigaretteTotalPacks,
            $referrerName, $patientPhone, $guardianName, $guardianPhone, 
            $diagnosis, $doctorName, $notes
        ]);
    }
    echo json_encode(['success' => true, 'message' => 'تم الحفظ بنجاح']);
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>