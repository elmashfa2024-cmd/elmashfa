<?php

header('Content-Type: application/json; charset=utf-8');

require_once '../config/database.php';

$archive = $pdo->query("SELECT * FROM patients WHERE status='archived' ORDER BY exit_date DESC")->fetchAll();
echo json_encode(['success' => true, 'data' => $archive]);
?>