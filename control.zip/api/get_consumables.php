<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$patients = $pdo->query("SELECT * FROM patients WHERE status='active' ORDER BY name")->fetchAll();

// نضيف days_stayed لكل نزيل
foreach ($patients as &$p) {
    if ($p['cigarette_daily'] > 0 && !empty($p['entry_date'])) {
        $entryDate = new DateTime($p['entry_date']);
        $today = new DateTime();
        $p['days_stayed'] = $today->diff($entryDate)->days;
    } else {
        $p['days_stayed'] = 0;
    }
}

echo json_encode(['success' => true, 'data' => $patients]);
?>