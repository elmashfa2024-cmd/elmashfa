<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$updated = 0;

// جلب كل النزلاء النشطين اللي عندهم سجاير يومية
$patients = $pdo->query("SELECT id, cigarette_daily, cigarette_price, cigarette_debt, cigarette_debt_packs, cigarette_total_packs, cigarette_last_update FROM patients WHERE status='active' AND cigarette_daily > 0")->fetchAll();

foreach ($patients as $p) {
    $lastUpdate = $p['cigarette_last_update'];
    $today = date('Y-m-d');
    
    // لو آخر تحديث كان الشهر اللي فات أو أقدم
    if (!$lastUpdate || $lastUpdate <= date('Y-m-d', strtotime('-25 days'))) {
        $daily = $p['cigarette_daily'];
        $price = $p['cigarette_price'];
        $monthlyPacks = ceil($daily * 30 / 20);
        $monthlyDebt = $monthlyPacks * $price;
        
        // تحديث المديونية
        $pdo->prepare("UPDATE patients SET 
            cigarette_debt = cigarette_debt + ?,
            cigarette_debt_packs = cigarette_debt_packs + ?,
            cigarette_total_packs = cigarette_total_packs + ?,
            cigarette_last_update = CURDATE()
            WHERE id = ?")->execute([$monthlyDebt, $monthlyPacks, $monthlyPacks, $p['id']]);
        
        $updated++;
    }
}

echo json_encode(['success' => true, 'updated' => $updated]);
?>