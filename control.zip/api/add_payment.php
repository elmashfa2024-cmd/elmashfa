<?php

header('Content-Type: application/json; charset=utf-8');


require_once '../config/database.php';

$data = json_decode(file_get_contents('php://input'), true);

$patientId = $data['patient_id'] ?? 0;
$amount = $data['amount'] ?? 0;
$paymentDate = $data['payment_date'] ?? date('Y-m-d');
$paymentMethod = $data['payment_method'] ?? 'كاش';
$receivedFrom = $data['received_from'] ?? '';
$notes = $data['notes'] ?? '';

if (!$patientId || !$amount) {
    echo json_encode(['success' => false, 'message' => 'اختر النزيل وادخل المبلغ']);
    exit;
}

// إضافة الدفعة
$stmt = $pdo->prepare("INSERT INTO payments (patient_id, amount, payment_method, received_from, notes, payment_date, recorded_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->execute([$patientId, $amount, $paymentMethod, $receivedFrom, $notes, $paymentDate, $_SESSION['user_id']]);

// تحديث المدفوع والمديونية
$patient = $pdo->prepare("SELECT * FROM patients WHERE id=?");
$patient->execute([$patientId]);
$p = $patient->fetch();

$newPaid = $p['total_paid'] + $amount;
$newDebt = max(0, $p['total_debt'] - $amount);

// لو دفع أكثر من المديونية، يتحول لرصيد
if ($amount > $p['total_debt']) {
    $creditAdded = $amount - $p['total_debt'];
    $newDebt = 0;
    $newCredit = $p['credit_balance'] + $creditAdded;
    $stmt = $pdo->prepare("UPDATE patients SET total_paid=?, total_debt=?, credit_balance=?, risk_level='low' WHERE id=?");
    $stmt->execute([$newPaid, $newDebt, $newCredit, $patientId]);
} else {
    $stmt = $pdo->prepare("UPDATE patients SET total_paid=?, total_debt=? WHERE id=?");
    $stmt->execute([$newPaid, $newDebt, $patientId]);
}

echo json_encode(['success' => true, 'message' => 'تم تسجيل الدفعة']);
?>