<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$visits = $pdo->query("
    SELECT v.*, p.name as patient_name, p.next_visit_date
    FROM visits v
    JOIN patients p ON v.patient_id = p.id
    ORDER BY v.visit_date DESC, v.visit_time DESC
    LIMIT 50
")->fetchAll();

echo json_encode(['success' => true, 'data' => $visits]);
?>