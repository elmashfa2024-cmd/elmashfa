<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

$data = json_decode(file_get_contents('php://input'), true);

$name = $data['name'] ?? '';
$phone = $data['phone'] ?? '';
$username = $data['username'] ?? '';
$password = $data['password'] ?? '';

if (empty($name)) {
    echo json_encode(['success' => false, 'message' => 'الاسم مطلوب']);
    exit;
}

try {
    // إضافة مستخدم جديد لو فيه يوزرنيم وباسورد
    $userId = null;
    if (!empty($username) && !empty($password)) {
        $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, role) VALUES (?, MD5(?), ?, 'referrer')");
        $stmt->execute([$username, $password, $name]);
        $userId = $pdo->lastInsertId();
    }

    // إضافة محول
    $stmt = $pdo->prepare("INSERT INTO referrers (user_id, name, phone) VALUES (?, ?, ?)");
    $stmt->execute([$userId, $name, $phone]);

    echo json_encode(['success' => true, 'message' => 'تم إضافة المحول']);
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>